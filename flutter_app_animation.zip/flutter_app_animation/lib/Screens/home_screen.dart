import 'package:flutter/material.dart';
import 'package:flutter_app_animation/Screens/animated_container_screen.dart';
import 'package:flutter_app_animation/Screens/animated_opacity_screen.dart';
import 'package:flutter_app_animation/Screens/animation_controller_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Animation Screens"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: const Text("Animated Container"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AnimatedContainerScreen(),
                  ),
                );
              },
            ),
            ElevatedButton(
              child: const Text("Animated Opacity"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AnimatedOpacityScreen(),
                  ),
                );
              },
            ),
            ElevatedButton(
              child: const Text("Animation Controller"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AnimationControllerScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}